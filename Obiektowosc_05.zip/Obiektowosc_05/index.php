<?php
require_once dirname(__FILE__).'/config.php';
include $conf->root_path.'/app/kontroler.php';