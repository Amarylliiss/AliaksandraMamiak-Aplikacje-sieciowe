<?php
class CalcForm {
	public $kwota;
	public $okres;
	public $procent;
} 