<?php
require_once dirname(__FILE__).'/../config.php';

require_once _ROOT_PATH.'/lib/smarty/Smarty.class.php';



function getParams(&$kwota,&$lata,&$procent){
	$kwota = isset($_REQUEST['kwota']) ? $_REQUEST['kwota'] : null;
	$lata = isset($_REQUEST['lata']) ? $_REQUEST['lata'] : null;
	$procent = isset($_REQUEST['proc']) ? $_REQUEST['proc'] : null;	
}


function validate(&$kwota,&$lata,&$procent,&$messages){
	
	if ( ! (isset($kwota) && isset($lata) && isset($procent))) {
		
		return false;
	}

if ( $kwota == "") {
	$messages [] = 'Nie podano kwoty kredytowej';
}
if ( $lata == "") {
	$messages [] = 'Nie podano okresu splaty';
}
if ( $procent == "") {
	$messages [] = 'Nie podano oprocentowania';
}


	if (count ( $messages ) != 0) return false;
	

if (! is_numeric( $kwota )) {
		$messages [] = 'Pierwsza wartość nie jest liczbą całkowitą';
	}
	
	if (! is_numeric( $lata )) {
		$messages [] = 'Druga wartość nie jest liczbą całkowitą';
	}	
	if (! is_numeric( $procent )) {
		$messages [] = 'Trzecia wartość nie jest liczbą całkowitą';
	}

	if (count ( $messages ) != 0) return false;
	else return true;
}

function process(&$kwota,&$lata,&$procent,&$messages,&$result){

	
	$kwota = intval($kwota);
	$lata = intval($lata);
	$procent = intval($procent);
	
	$result = (($procent/100*$lata*$kwota)+$kwota)/($lata*12);
}

$kwota = null;
$lata = null;
$procent = null;
$result = null;
$messages = array();
$hide_intro = true;


getParams($kwota,$lata,$procent);
if ( validate($kwota,$lata,$procent,$messages, $hide_intro) ) { 
	process($kwota,$lata,$procent,$messages,$result);
}

$smarty = new Smarty();

$smarty->assign('app_url',_APP_URL);
$smarty->assign('root_path',_ROOT_PATH);
$smarty->assign('page_title','Kalkulator Kredytowy');
$smarty->assign('page_description','Profesjonalne szablonowanie oparte na bibliotece Smarty');
$smarty->assign('page_header','Szablony Smarty');

$smarty->assign('hide_intro',$hide_intro);


$smarty->assign('kwota',$kwota);
$smarty->assign('kwota',$lata);
$smarty->assign('kwota',$procent);
$smarty->assign('result',$result);
$smarty->assign('messages',$messages);



$smarty->display(_ROOT_PATH.'/app/calc.html');